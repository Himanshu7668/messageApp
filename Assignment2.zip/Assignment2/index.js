const ws = require('ws');
const loadDb = require('./util/db');
const { getOpenTime, getCloseTime, getDefaultData } = require('./util/helper');

class Trade {
    constructor(coin) {
        this.coin = coin;
        this.cointToL = (this.coin).toLowerCase()
        this.socketURL = `wss://fstream.binance.com/ws/${this.cointToL}@trade`;
        this.websocket = new ws(this.socketURL);
        this.oneMinRec = getDefaultData();
        this.fiveMinRec = getDefaultData();
        this.db = loadDb(this.coin)
    }

    getData = async () => {
        let oneMinOpenTime = getOpenTime(1);
        let oneMinCloseTime = getCloseTime(1);
        this.websocket.on('message', async (data) => {
            const rawData = JSON.parse(data);
            const timestamp = new Date(rawData.T);
            if (timestamp <= oneMinCloseTime) {
                console.log("under 1 min");
                const recordArrInSameTime = rawData;
                this.oneMinRec = this.updateOHCLValues(recordArrInSameTime, this.oneMinRec);
            } else {
                this.oneMinRec.openTime = oneMinOpenTime;
                this.oneMinRec.closeTime = oneMinCloseTime;
                this.oneMinRec.key = "1 Min";
                await this.pushToDb(this.oneMinRec);
                this.oneMinRec.openTime = "";
                oneMinOpenTime = oneMinCloseTime;
                oneMinCloseTime = getCloseTime(1);
                const recordArrInSameTime = rawData;
                this.oneMinRec = this.updateOHCLValues(recordArrInSameTime, this.oneMinRec);
            }
        })
    }

    updateOHCLValues = (data, initialValues) => {
        if (!initialValues["open"]) {
            initialValues = {
                open: data.p,
                close: data.p,
                high: data.p,
                low: data.p,
                type: this.coin
            }
        }
        if (initialValues.high < data.p) {
            initialValues["high"] = data.p;
        }
        if (initialValues.low > data.p) {
            initialValues["low"] = data.p
        }
        initialValues["close"] = data.p;
        return initialValues;
    }
    
    pushToDb = async (data) => {
        try {
            const response = await (await this.db)
                .collection(`${this.coin}--trade--${data.key}`)
                .insertOne({ ...data, createdAt: new Date() });
            if (response) {
                console.log(`response added successfully for ${data.type} ${data.key}`);
                console.log(response);
            }
    
        } catch (err) {
            console.log("could not push to db");
        }
    }
}


const t = new Trade("BTCUSDT");
t.getData();
