const diff = 1000 * 60

const openTime = (frame)=>{
    let val = diff * frame;
    return new Date(Math.floor(new Date().getTime()/val)*val)
}

const closeTime = (frame) => {
    let val = diff * frame;
    return new Date(Math.ceil(new Date().getTime()/val)*val)
}

const defaultData = () => ({
    high: "",
    low: "",
    open: "",
    close: "",
    openTime: "",
    closeTime: "",
    key: "",
})
module.exports = { openTime, closeTime, defaultData };

// export {
//     openTime,
//     closeTime,
//     defaultData
// }