const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

const url = 'mongodb://localhost:27017';
let db;

const loadDb = async()=>{
    if(db){
        return db
    }
    try{
      const client = await MongoClient.connect(url);
      db = client.db('HIGH_MAX');
    } catch(err){
        console.log(err);
    }
    return db;
}

module.exports = loadDb;