const ws = require('ws');
const dbcon = require('./utility/database');

const {openTime, closeTime, defaultData} = require('./utility/helper');
//import { openTime, closeTime, defaultData } from "./utility/helper.js";
class Trade {
   constructor(coin) {
       this.coin
       this.url = `wss://ws.bitmex.com/realtime?subscribe=trade:${coin}`;
       this.websocket = new ws(this.url);
       this.oneMinRec = defaultData();
       this.fiveMinRec = defaultData();
       this.db = dbcon(this.coin)
   }

   getData = async ()=>{
      //const d = new Date().getTime();
      let oneMinOpenTime = openTime(1);
      let oneMinCloseTime = closeTime(1);
      let fiveMinOpenTime = openTime(5);
      let fiveMinCloseTime = closeTime(5);
      this.websocket.on('message', async (data)=>{
         const rawData = JSON.parse(data.toString());
         if(rawData.data){
            const timestamp = new Date(rawData.data[0]["timestamp"])
            if(timestamp <= oneMinCloseTime){
               console.log("under 1 min");
               const recordArrayInSameTime = rawData.data;
               this.oneMinRec = this.updateOHCLValues(recordArrayInSameTime, this.oneMinRec);
            }else{
                this.oneMinRec.openTime = oneMinOpenTime;
                this.oneMinRec.closeTime = oneMinCloseTime;
                this.oneMinRec.key = "1 min";
                await this.pushTOdb(this.oneMinRec);
            }
         }
      })
   }

   updateOHCLValues = (Data, initialValues)=>{
     Data.forEach((el)=>{
         if(!initialValues.open){
             initialValues = {
                 open : el.price,
                 high : el.price,
                 close: el.price,
                 low : el.price,
                 type : this.coin     
             }
         }
         if(initialValues.high < el.price){
            initialValues["high"] = el.price;
         }
         if(initialValues.low > el.price){
            initialValues["low"] = el.price;
         }
         initialValues["close"] = el.price
     });
     return initialValues;
   }

   pushTOdb = async (data)=>{
      try{
        const colData = await (await this.db)
        .collection(`${this.coin}-Trade-${data.key}`)
        .insertOne({...data, createdAt : new Date()});
        if (colData) {
            console.log(
              `Document added successfully for ${data.type} ${data.key}`,
              colData
            );
          }
      }catch(err){
        console.error(err);
      }
   }
}





const t = new Trade("XBTUSD");
t.getData();






// const ws = require('ws');
// const url = "wss://ws.bitmex.com/realtime?subscribe=trade:XBTUSD";
// // const diff1 = 1000 * 60 * 1;
// // const diff5 = 1000 * 60 * 5
// const {openTime, closeTime, defaultData} = require('./utility/helper')
// const websocket = new ws(url);
// websocket.on('open', ()=>{
//     console.log("connected");
// })
// websocket.on('message', (e)=>{
//     const rawData = JSON.parse(e);
//     //console.log(rawData);
//     if(rawData.data){
//         //console.log(rawData.data[0]["timestamp"])
//         // one min time frame
//         // let openTimeofOneMin = new Date(Math.floor(new Date(rawData.data[0]["timestamp"]).getTime() / diff1) * diff1);
//         // let closeTimeofOneMin = new Date(Math.ceil(new Date(rawData.data[0]["timestamp"]).getTime() / diff1) * diff1);
//         // console.log(openTimeofOneMin);
//         // console.log(closeTimeofOneMin);

//         // console.log("====================>")
//         // //  five min time frame

//         // let openTimeofFiveMin = new Date(Math.floor(new Date(rawData.data[0]["timestamp"]).getTime() / diff5) * diff5);
//         // let closeTimeofFiveMin = new Date(Math.ceil(new Date(rawData.data[0]["timestamp"]).getTime() / diff5) * diff5);
//         // console.log(openTimeofFiveMin);
//         // console.log(closeTimeofFiveMin);

//         // const timestamp = new Date(rawData?.data?.[0]?.timestamp);
//         const timestamp = new Date(rawData.data[0]["timestamp"]).getTime();
//         console.log(timestamp);

//     }
    
// })
// websocket.on('error', (message) => {
//     console.log("error connecting websocket");
// });
// websocket.on('close', (message) => {
//     console.log("websocket connection closed");
// });