const redis = require("redis");
const redisclient = redis.createClient({
    port: '127.0.0.1',
    host: 6379,
});
  

const heatmap_z_oi_Bitmex_1m_btcusd = async () => {
    await redisclient.connect();
    const fooValue = await redisclient.get('heatmap_z_ns_Bitmex_1m_btcusd');
    console.log(fooValue);
};

heatmap_z_oi_Bitmex_1m_btcusd();

redisclient.on("ready", () => {
    console.log("Connected!");
});


redisclient.on("error", (err) => {
    console.log("Error in the Connection");
});


// console.log(redisclient.get('heatmap_z_oi_Bitmex_1m_btcusd'))