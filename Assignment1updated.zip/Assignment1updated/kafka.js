const { Kafka } = require('kafkajs');

const clientId = "Himanshu-bitmax";
const brokers = ["18.217.154.66:9092", "18.217.154.66:9094", "18.217.154.66:9093"];

const kafka = new Kafka({clientId, brokers});

module.exports = kafka

