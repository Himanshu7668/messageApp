const redis = require("redis");
const redisclient = redis.createClient({
    port: 'locahost',
    host: 6379,
});
  
(async () => {
    await redisclient.connect();
})();
  
console.log("Connecting to the Redis");
// (async ()=>{
//     abc = await redisclient.get(heatmap_z_oi_Bitmex_1m_btcusd)
//     console.log(abc)
// })  
redisclient.on("ready", () => {
    console.log("Connected!");
});

redisclient.get('heatmap_z_oi_Bitmex_1m_btcusd', (err, reply) => {
    if (err) throw err;
    console.log("====================",reply);
});

// redisclient.get('heatmap_z_oi_Bitmex_1m_btcusd', function(err, reply) {
//     console.log(reply); // ReactJS
//   });

redisclient.on("error", (err) => {
    console.log("Error in the Connection");
});


// console.log(redisclient.get('heatmap_z_oi_Bitmex_1m_btcusd'))