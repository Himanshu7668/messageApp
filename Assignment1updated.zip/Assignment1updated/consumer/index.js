const http = require('http');
const kafka = require('./kafka');
const websocket = require('ws');
const { WebSocketServer } = require('ws');

const PORT = 8080;
const topic = "Himanshu-XBTUSD";
const consumer = kafka.consumer({ groupId: "himanshu" });

const server = http.createServer(function (request, response) {
    response.writeHead(200, { "Content-Type": "text/html" });
    response.write("message ==> Server is live.");
    response.end();
});

const wss = new WebSocketServer({
    server,
})

wss.on('connection', function connection(ws, req) {
    console.log("connected to websocket server");
    ws.requestedCoin = req.url.split("/")[1];
    //console.log(req.url);
    console.log(req.url.split('/'));
    ws["coin"] = req.url.split("/")[1];
    ws["tf"] = req.url.split("/")[2];

    ws.on("message", (req) => {
        ws.send("Working");
    });

    ws.on("close", (req) => {
        console.log("Websocket client connection closed", req);
    });
})

const run = async () => {
    await consumer.connect();
    // topic.forEach(async (t) => {
    //     if (t) {
    //         await consumer.subscribe({
    //             topics: t,
    //             fromBeginning: false
    //         })
    //     }
    // })
    await consumer.subscribe({
        topic : topic
    })
    await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
           //const prefix = `${topic}[${partition} | ${message.offset}] / ${message.timestamp}`;

            console.log(
                "======================================================================="
            );
            // console.log(
            //     `- ${prefix} ${message.key}# `,
            //     JSON.parse(message.value.toString())
            // );
            console.log(JSON.parse(message.value))

            console.log(
                "======================================================================="
            );
            wss.clients.forEach(function each(client) {
                let type = JSON.parse(message.value.toString()).type;

                if (client["coin"] === type) {
                    console.log(JSON.parse(message.value));
                    client.send(
                        JSON.stringify(JSON.parse(message.value)[client["tf"]])
                    );
                }
            })
        }
    })
}

run().catch((e)=>{ console.log(e) });

server.listen(PORT, () => {
    console.log(`Server is up and running on port ${PORT}`);
  });
  
