 const Handler = require('./controller/handler')
 const handler = new Handler("bitmex", "xbt");
// const handlerETH = new Handler("bitmex", "eth");
const WebSocket = require('ws');
const ReconnectingWebSocket = require('reconnecting-websocket');
const options = {
    WebSocket: WebSocket
};
// const { handler } = require('./handler')
const webSocket = new ReconnectingWebSocket("wss://www.bitmex.com/realtime", undefined, options);
var msg = JSON.stringify({
    op: "subscribe",
    args: ["trade:XBTUSD", "trade:ETHUSD"]
});
webSocket.addEventListener('open', (message) => {
    console.log("websocket for trade opened!");
    webSocket.send(msg);
});
webSocket.addEventListener('message', (e) => {
    const rawData = JSON.parse(e.data);
    //console.log(rawData);
    if (rawData.action === "insert") {
        for (let i = 0; i < rawData.data.length; i++) {
           if (rawData.data[i].symbol === "XBTUSD"){
            handler.calculate(rawData.data);
           }
        //    if (rawData.data[i].symbol === "ETHUSD"){
        //     handlerETH.calculate(rawData.data);
        //    }
         }
     }
})
webSocket.addEventListener('error', (message) => {
    console.log("error connecting websocket");
});
webSocket.addEventListener('close', (message) => {
    console.log("websocket connection closed");
});


