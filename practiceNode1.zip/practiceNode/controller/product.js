const Product = require('../modles/porduct');

exports.addProduct = (req, res, next)=>{
   const {title, brand} = req.body
   const prod = new Product(title, brand);
   console.log(req.body)
   prod.save()
   .then(result=>{
     return res.status(200).json(result);
    //    console.log(res)
   })
   .catch(err=>{
       console.log(err);
   })
}

exports.getProduct = async (req, res, next) =>{
   const pords = await Product.fatchAll();
   return res.status(200).json(pords);
}