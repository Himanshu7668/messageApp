var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

const diff1 = 1000 * 60 * 1;
class Handler {
    constructor(exchange, coin) {

        //const diff5 = 1000 * 60 * 5;
        this.exchange = exchange;
        this.coin = coin;
        this.oneMin = {
            _id: new Date(Math.floor(new Date('2022-03-15T00:00:00.000Z').getTime() / diff1) * diff1),
            openDate: new Date(Math.floor(new Date('2022-03-15T00:00:00.000Z').getTime() / diff1) * diff1),
            createOn: new Date(),
            open: 0,
            close: 0,
            high: 0,
            low: 0,
            volume: 0
        }
    }

    calculate = (data) => {
        console.log(data);
        for (let i = 0; i < data.length; i++) {
            const currentDateTime = new Date(Math.floor(new Date(data[i].timestamp).getTime() / diff1) * diff1);
            if (this.oneMin.open === 0 ) {
                this.oneMin.open=data[i].price;
                
            }
            if(this.oneMin.high < data[i].price){
                this.oneMin.high=data[i].price
            }
            if(this.oneMin.low > data[i].price || this.oneMin.low === 0){
                this.oneMin.low=data[i].price
            }
            this.oneMin.close=data[i].price
            this.oneMin.volume+=data[i].size
            
            if(currentDateTime > this.oneMin.openDate){ 
                MongoClient.connect(url, (err, db)=>{
                    if(err) throw err;
                    var dbo = db.db("HIGH_MAX");
                      
                     dbo.collection("data").insertOne(this.oneMin, function(err, res){
                        if(err) throw err;
                        console.log("1 document inserted");
                        db.close();
                    })    
                    this.oneMin = {
                        _id: new Date(Math.floor(new Date(data[i].timestamp).getTime() / diff1) * diff1),
                        openDate: new Date(Math.floor(new Date(data[i].timestamp).getTime() / diff1) * diff1),
                        createOn:new Date(),
                        open: data[i].price,
                        close: 0,
                        high: 0,
                        low: 0,
                        volume: 0
                    } 
                })     
            }

        }
    }

}

module.exports = Handler

//  const a = new Handler();
//  console.log(a.oneMin.a)
// a.calculate();

