const express = require('express');
const app = express();
const bodyParser = require('body-parser')

const mongoConnect = require('./util/database').mongoConnect;

const porductRoutes = require('./routes/product');
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended : false}));
app.use('/product', porductRoutes);

//console.log("Hello form hyblockCapital from Diverse Lynx");
mongoConnect(()=>{
    //console.log(client)
    app.listen(3000);
})

