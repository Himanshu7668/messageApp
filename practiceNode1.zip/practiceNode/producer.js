const { Kafka } = require('kafkajs');

async function createPartition(){
    const kafka = new Kafka({
        clientId : "player-jersey",
        brokers : [
            "18.217.154.66:9092",
            "18.217.154.66:9094",
            "18.217.154.66:9093",
          ]
    })

    const admin = kafka.admin();
    await admin.connect();

    await admin.createParTopics({
        topics : [
            {
                "topic" : "jersy",
                "numPartitions" : 2
            },
        ],
    });
    console.log("2 partition created")
    await admin.disconnect();

}
createPartition()
