const getDb = require('../util/database').getDb

class Product {
    constructor(title, brand) {
        this.title = title;
        this.brand = brand
    }

    save() {
        const db = getDb();
        return db.collection('product')
            .insertOne(this)
            .then(res => {
                console.log(res)
            })
            .catch(err => {
                console.log(err)
            })
    }

    static async fatchAll(){
        const db = getDb();
        const prods = await db.collection('product').find().toArray();
        return prods;
    }

}

module.exports = Product;