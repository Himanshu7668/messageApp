//let date = new Date().getTime();
const diff1 = 1000 * 60 * 1;
//const diff5 = 1000 * 60 * 5;
// let date =  new Date(Math.floor(new Date().getTime() / diff1) * diff1)
// let date1 = new Date().getTime()

// console.log(date)
// console.log(date1)

// const startDate = new Date(2020, 1, 1);  
// const endDate = new Date(2020, 2, 1);  
// const seconds = (endDate.getTime() - startDate.getTime()) / 1000;  
// console.log(seconds)

// let openDate = new Date(Math.floor(new Date('2022-03-15T00:00:00.000Z').getTime() / diff1) * diff1)
// let createOn = new Date()
// console.log(openDate)
// console.log(createOn)
// let diff = createOn - openDate;
// console.log(diff)

//var startDate = new Date(2022, 5, 25);
// Do your operations
//var endDate   = new Date(2022, 5, 25);
//var seconds = (endDate.getTime() - startDate.getTime()) / 1000;

//console.log(seconds)

let openDate = new Date(Math.floor(new Date().getTime() / diff1) * diff1);
let createOn = new Date().getTime()
console.log(openDate)
 console.log(createOn)
var seconds = (openDate - createOn) / 1000;
console.log(seconds)
// console.log(createOn)

