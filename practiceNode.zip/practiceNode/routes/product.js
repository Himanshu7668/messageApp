const express = require('express');
const productController = require('../controller/product');

const router = express.Router();

router.post('/add-product', productController.addProduct);

router.get('/get-product', productController.getProduct);

module.exports = router