const getDb = require('../util/database').getDb

class Product {
    constructor(title, brand) {
        this.title = title;
        this.brand = brand
    }

    save() {
        const db = getDb();
        return db.collection('product')
            .insertOne(this)
            .then(res => {
                console.log(res)
            })
            .catch(err => {
                console.log(err)
            })
    }

    static fatchAll(){
        return db.collection('product').find()
    }

}

module.exports = Product;