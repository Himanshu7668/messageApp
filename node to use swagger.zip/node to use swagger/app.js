const express = require('express');
const bodyParser = require('body-parser')
const app = express();
const postRoutes = require('./routes/route');
const dbConnect = require('./utils/db');
const swaggerJsDoc = require('swagger-jsdoc');
const swaggerUI = require('swagger-ui-express');

app.use(bodyParser.json());

const options = {
    definition: {
        openapi : '3.0.0',
        info : {
            title: 'Node JS with Swagger',
            version: '1.0.0',
        },
        servers:[
            {
               url: 'http://localhost:3000'
            }
        ]
    },
    apis: ['./app.js', './routes/route.js']
}

const swaggerSpecs = swaggerJsDoc(options);
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpecs))

app.use(bodyParser.urlencoded({extended: true}));
app.use('/app', postRoutes);


console.log("this project is to learn swagger");
dbConnect('swagger-learning');

app.listen(3000);