const express = require("express");

const router = express.Router();

const addPost = require("../controller/controller");

/**
 * @swagger
 *  components:
 *      schemas:
 *          product:
 *                  type: object
 *                  properties:
 *                      title:
 *                          type: string
 *                      name: 
 *                          type: string
 */

/**
 * @swagger
 * /app/checking:
 *  get:
 *      summary: This api is used to check if get method is working or not
 *      description: This api is used to check if get method is working or not
 *      responses:
 *          200:
 *              description: To test Get Method
 */
router.get("/checking", addPost.Checking);


/**
 * @swagger
 * /app/addPost:
 *  post:
 *      summary: To add the product in the db
 *      description: This api is use to add product in db
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      $ref : '#components/schemas/product'
 *      responses:
 *          200:
 *              description: Added successfully
 */
router.post("/addPost", addPost.insertProduct);

/**
 * @swagger
 * /app/getPost:
 *  get:
 *      summary: To get all product from the db
 *      description: This api is to fetch all products from the db
 *      responses:
 *          200:
 *              description: To fetch all product from the db
 *              content:
 *                  application/json:
 *                      schema: 
 *                          type: array
 *                          items:
 *                              $ref : '#components/schemas/product'
 *          404:
 *              description: no product found
 */
router.get("/getPost", addPost.fetchProuduct);

module.exports = router;
