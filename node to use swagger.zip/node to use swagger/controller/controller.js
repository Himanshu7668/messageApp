const dbConnect = require("../utils/db");
const Product = require("../modles/modle");

// checking the api is working or not
exports.Checking = async (req, res) => {
  return res.status(200).json({ message: "working" });
};

// inserting product in db
exports.insertProduct = async (req, res) => {
  let title = req.body.title;
  let name = req.body.name;
  try {
    console.log(title, name);
    const newProduct = new Product(title, name);
    const db = await dbConnect("swagger_learning");
    db.collection("productDb").insertOne(newProduct);
    console.log("added to db");
    return res.status(200).json({ message: "product added successfully" });
  } catch (e) {
    console.log(e);
  }
};

// fetching product
exports.fetchProuduct = async(req, res) =>{
    try{
      let data = await(await dbConnect("swagger_learning")).collection("productDb").find({}).toArray();
      if(!data){
        return res.status(404).json({message: "no product found"})
      }
      return res.status(200).json(data);
    }catch(e){
        console.log(e)
    }
}
