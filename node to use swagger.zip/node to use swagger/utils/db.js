const mongodb = require("mongodb");
const MongoClient = mongodb.MongoClient;
DB_URL = "mongodb://localhost:27017";
let db;
const dbConnect = async (dbName) => {
  if (db) {
    return db;
  }
  try {
    const client = await MongoClient.connect(DB_URL);
    db = client.db(dbName);
  } catch (e) {
    console.log("sdggsd");
  }
  return db;
};
// (async ()=>{
//     const abc = await dbConnect("swagger_learning");
//     console.log("===>",abc);
// })()
module.exports = dbConnect;