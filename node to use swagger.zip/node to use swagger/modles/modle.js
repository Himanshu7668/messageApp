class Product {
  constructor(title, name) {
    this.title = title;
    this.name = name;
  }
}

module.exports = Product;
