const ws = require('ws');
const loadDb = require('./util/db');
//const Kafka = require('./kafka')
//import kafka from "./kafka.js";
const crypto = require('crypto');
const { getOpenTime, getCloseTime, getDefaultData } = require('./util/helper')


const { Kafka } = require("kafkajs");

const clientId = "Himanshu123";

const brokers = ["localhost:9092"];

//const topic = "himanshutopic";

const kafka = new Kafka({ clientId, brokers });

const producer = kafka.producer();

class Trade {
    constructor(coin) {
        this.coin = coin;
        this.socketURL = `wss://ws.bitmex.com/realtime?subscribe=trade:${coin}`;
        this.websocket = new ws(this.socketURL)
        this.oneMinRec = getDefaultData();
        this.fiveMinRec = getDefaultData();
        this.db = loadDb(this.coin)
    }

    getData = async () => {
        let oneMinOpenTime = getOpenTime(1);
        let oneMinCloseTime = getCloseTime(1);
        this.websocket.on('message', async (data) => {
            let rawData = JSON.parse(data.toString());
            if (rawData.data) {
                const timestamp = new Date(rawData.data[0]["timestamp"]);
                if (timestamp <= oneMinCloseTime) {
                    console.log("under 1 min");
                    const recordArrInSameTime = rawData.data;
                    this.oneMinRec = this.updateOHCLValues(recordArrInSameTime, this.oneMinRec);
                } else {
                    this.oneMinRec.openTime = oneMinOpenTime;
                    this.oneMinRec.closeTime = oneMinCloseTime;
                    this.oneMinRec.key = "1 Min";
                    await this.pushToDb(this.oneMinRec);
                    this.oneMinRec.openTime = "";
                    oneMinOpenTime = oneMinCloseTime;
                    oneMinCloseTime = getCloseTime(1);
                    const recordArrInSameTime = rawData.data;
                    this.oneMinRec = this.updateOHCLValues(recordArrInSameTime, this.oneMinRec);
                }
            }
        })
    }

    updateOHCLValues = (data, initialValues) => {
        data.forEach((element) => {

            if (!initialValues["open"]) {
                initialValues = {
                    open: element.price,
                    close: element.price,
                    high: element.price,
                    low: element.price,
                    type: this.coin
                }
            }
            if (initialValues.high < element.price) {
                initialValues["high"] = element.price;
            }
            if (initialValues.low > element.price) {
                initialValues["low"] = element.price
            }
            initialValues["close"] = element.price;
        });
        return initialValues;
    }

    pushToDb = async (data) => {
        try {
            const response = await (await this.db)
                .collection(`${this.coin}--trade--${data.key}`)
                .insertOne({ ...data, createdAt: new Date() });
            if (response) {
                console.log(`response added successfully for ${data.type} ${data.key}`);
                console.log(response);
            }

        } catch (err) {
            console.log("could not push to db");
        }
    }

    pushTOKafka = async () => {
        //const producer = Kafka.producer();
        await producer.connect();
        console.log(`connected to Himanshu-${this.coin} topic`);
        setInterval(async () => {
            producer.send({
                topic: `Himanshu-${this.coin}`,
                messages: [{
                    key: crypto.randomUUID(),
                    value: JSON.stringify({
                        "1Min": this.oneMinRec,
                        type: this.coin
                    })
                }]
            })
        }, 1000)
    }
}



const t = new Trade("XBTUSD");
t.getData();
t.pushTOKafka();
