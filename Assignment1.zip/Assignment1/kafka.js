const { Kafka } = require('kafkajs');

const clientId = "Himanshu-bitmax";
const brokers = ["localhost:9092"];

const kafka = new Kafka(clientId, brokers);

module.exports = kafka

