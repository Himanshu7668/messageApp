const diff = 1000 * 60;

const getOpenTime = (frame) => {
    let val = diff * frame;
    return new Date(Math.floor(new Date().getTime() / val) * val);
}

const getCloseTime = (frame) => {
    let val = diff * frame;
    return new Date(Math.ceil(new Date().getTime() / val) * val)
}

const getDefaultData =  () => ({
    high: "",
    low: "",
    open: "",
    close: "",
    openTime: "",
    closeTime: "",
    key: "",
})

module.exports = {
    getOpenTime,
    getCloseTime,
    getDefaultData
}