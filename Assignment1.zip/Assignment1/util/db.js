const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

const url = 'mongodb://localhost:27017';

let db;

const loadDb = async (dbNmae) => {
    if (db) {
        return db;
    }
    try {
        const client = await MongoClient.connect(url);
        db = client.db(dbNmae);
    } catch (err) {
        console.log(err)
    }
    return db;
}

module.exports = loadDb;