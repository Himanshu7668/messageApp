const reqDataformat = {
    t: [],
    o: [],
    h: [],
    l: [],
    c: [],
}

module.exports = { reqDataformat };