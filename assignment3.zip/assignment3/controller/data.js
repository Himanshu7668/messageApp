const loadDb = require('../util/db');
const { reqDataformat } = require('../util/helper');

exports.resultData = async (req, res) => {
    try {
        const data = await (await loadDb("XBTUSD")).collection('XBTUSD--trade--1 Min').find({}).toArray()
        if (!data) {
            console.log("no data found");
        }
        else {
              
            console.log("=====================>", "working");
            // reqDataformat["t"][0] = data[0]["openTime"];
            // console.log(reqDataformat["t"]);
            // console.log(reqDataformat)
            // const resData = data.map((objEl)=>{
            //     reqDataformat["t"] = objEl.openTime;
            //     reqDataformat["o"] = objEl.open;
            //     reqDataformat["h"] = objEl.high;
            //     reqDataformat["l"] = objEl.low;
            //     reqDataformat["c"] = objEl.close;
                
            // })
            // console.log(resData);
            for(let i = 0 ; i < data.length; i++){
               reqDataformat["t"][i] = data[i]["openTime"]/1000;
               reqDataformat["o"][i] = data[i]["open"]
               reqDataformat["h"][i] = data[i]["high"]
               reqDataformat["l"][i] = data[i]["low"]
               reqDataformat["c"][i] = data[i]["close"]
            }
            return res.status(200).json(reqDataformat);
        }
    } catch (err) {
        console.log(err);
    }
}