const express = require("express");
const bodyParser = require('body-parser');
const loadDb = require('./util/db');
const dataRouter = require('./router/data');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));

app.use('/app', dataRouter);


app.listen(3000);